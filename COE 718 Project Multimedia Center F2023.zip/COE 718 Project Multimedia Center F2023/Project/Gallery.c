/*----------------------------------------------------------------------------
 * Name:    Blinky.c
 * Purpose: LED Flasher and Graphic Demo
 * Note(s): 
 *----------------------------------------------------------------------------
 * This file is part of the uVision/ARM development tools.
 * This software may only be used under the terms of a valid, current,
 * end user licence from KEIL for a compatible version of KEIL software
 * development tools. Nothing else gives you the right to use this software.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2008-2011 Keil - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------*/
                  
#include <LPC17xx.H> /* LPC17xx definitions */
#include "Gallery.h"
#include "GLCD.h"
#include "LED.h"
#include "KBD.h"


extern unsigned char ClockLEDOn;
extern unsigned char ClockLEDOff;
extern unsigned char ClockANI;
extern unsigned int counter;

 extern unsigned char image1[];
 extern unsigned char image2[];
 extern unsigned char image3[];
 



void imageToLCD(int which)		//function for displaying image
{
	int delay = 0;
	if (which==0)
	{
		GLCD_Clear(Black);
		GLCD_Bitmap(45,20,200,180,image1);
	}
	else if (which==1)
	{
		GLCD_Clear(Black);
		GLCD_Bitmap(45,20,200,180,image2);
	}
	else if (which==2)
	{
		GLCD_Clear(Black);
		GLCD_Bitmap(45,20,200,180,image3);
	}
}

void photo_viewer (int mode)
{	
	int imageZoom=0;
	int image     =  0, DELAY = 0;		//variable that saves which picture to display
	int clockTimeOut   =  0;
	unsigned char *picture_ptr =0;
	int prevImage = get_button();
	int joystickInput = get_button();
	counter =0;
	imageToLCD(image);
	while (clockTimeOut <1)		//if the joystick has not pressed twice, we stay on photo viewer
	{	
		joystickInput = get_button();		//read the joystick
		if (joystickInput != prevImage)	//if sth change, then know what change it was
			{
				if (joystickInput == KBD_RIGHT)
					{
							image = image+1; //increment image
							image = image%3;	//we are only displaying 3 pictures
						  imageToLCD(image);	//display whatever image
							imageZoom = 0;
					}
				else if (joystickInput ==KBD_LEFT)
					{
						image = image-1; //decrement image
						if (image < 0)
								image = 2;			
						imageToLCD(image);	//display whatever image
						imageZoom = 0;
					}
				else if (joystickInput ==KBD_SELECT)
				{
					clockTimeOut ++;
				}
			  prevImage = joystickInput;
				counter =0;
		}
	}
	clockTimeOut = 0;	//before going out, set the clockTimeOut back to zero
	GLCD_Clear(Black);
	GLCD_DisplayString (0, 2, 1, "COE 718 Project");
	GLCD_DisplayString (1, 5, 1, "MAIN MENU");
	GLCD_DisplayString (2, 4, 1, "Apurva Patel");
}





